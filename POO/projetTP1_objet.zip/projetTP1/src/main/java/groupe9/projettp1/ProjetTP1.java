/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package groupe9.projettp1;

/**
 *
 * @author ADM
 */
public class ProjetTP1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
